// JavaScript to make the stars interactive
const stars = document.querySelectorAll('.star');
const ratingValue = document.getElementById('ratingValue');
let currentRating = 0;

// Add hover effect and click functionality
stars.forEach((star) => {
    star.addEventListener('mouseover', handleMouseOver);
    star.addEventListener('mouseout', handleMouseOut);
    star.addEventListener('click', handleClick);
});

// Mouse hover - highlight stars up to the one being hovered
function handleMouseOver(event) {
    const rating = event.target.getAttribute('data-value');
    highlightStars(rating);
}

// Mouse out - reset stars to the current rating
function handleMouseOut() {
    highlightStars(currentRating);
}

// On click - set the current rating and highlight stars accordingly
function handleClick(event) {
    currentRating = event.target.getAttribute('data-value');
    ratingValue.textContent = currentRating;
    highlightStars(currentRating);
}

// Function to highlight stars
function highlightStars(rating) {
    stars.forEach((star) => {
        star.classList.remove('active');
    });
    for (let i = 0; i < rating; i++) {
        stars[i].classList.add('active');
    }
}
