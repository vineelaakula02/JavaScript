// Get all the FAQ question elements
const faqQuestions = document.querySelectorAll('.faq-question');

// Add click event listeners to each FAQ question
faqQuestions.forEach((question) => {
  question.addEventListener('click', () => {
    // Get the answer related to the clicked question
    const answer = question.nextElementSibling;

    // Toggle the "active" class to show/hide the answer
    if (answer.style.maxHeight) {
      // If the answer is already open, close it
      answer.style.maxHeight = null;
    } else {
      // Close all other answers
      document.querySelectorAll('.faq-answer').forEach((el) => {
        el.style.maxHeight = null;
      });

      // Open the clicked answer
      answer.style.maxHeight = answer.scrollHeight + "px";
    }
  });
});
