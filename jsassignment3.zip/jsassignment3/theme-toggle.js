// Elements
const themeToggleBtn = document.getElementById('theme-toggle');
const themeStylesheet = document.getElementById('theme-stylesheet');

// Check if a theme is saved in localStorage
const savedTheme = localStorage.getItem('theme');

// Set the saved theme, or default to light
if (savedTheme) {
    themeStylesheet.href = savedTheme;
} else {
    themeStylesheet.href = 'light-theme.css';
}

// Toggle theme function
themeToggleBtn.addEventListener('click', () => {
    if (themeStylesheet.href.includes('light-theme.css')) {
        themeStylesheet.href = 'dark-theme.css';
        localStorage.setItem('theme', 'dark-theme.css'); // Save to localStorage
    } else {
        themeStylesheet.href = 'light-theme.css';
        localStorage.setItem('theme', 'light-theme.css'); // Save to localStorage
    }
});
